﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
	public partial class formularioPizarra : Form
	{
        bool dibujarPunto;
        Graphics gráfico;

        public formularioPizarra()
		{
			InitializeComponent();
            this.gráfico = CreateGraphics (); //por qué va ahí?
		}

        //cierra el formulario
        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        //dibuja un pto en la posición del puntero
        void dibujoPunto()
        {
            Point p;
            p = new Point(MousePosition.X, MousePosition.Y);
            p = this.PointToClient(p);
            //gráfico.DrawRectangle(Pens.Black,p.X, p.Y, 1, 1);
        }

        //dibuja una línea
        void dibujoLínea(int xa, int ya, int xb, int yb )
        {
            Point a,b;
            a = new Point(xa, ya);
            b = new Point (xb, yb);
            gráfico.DrawLine(Pens.Black, a, b);
        }

        //si esta activado el bool dibujar, entonces ejecuta dibujo punto al hacer click
        private void Form1_Click(object sender, EventArgs e)
        {
            if (dibujarPunto == true)
            {
                this.dibujoPunto();
            }                     
        }

        private void btnPunto_Click(object sender, EventArgs e)
        {
            dibujarPunto = true;
        }

        private void btnLínea_Click(object sender, EventArgs e)
        {
            OnMouseClick 
            Point p1;
            p1 = new Point(MousePosition.X, MousePosition.Y);

        }

        private void gb_Enter(object sender, EventArgs e)
        {

        }
	}
}
