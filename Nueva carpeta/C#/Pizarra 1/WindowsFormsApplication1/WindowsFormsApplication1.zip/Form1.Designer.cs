﻿namespace WindowsFormsApplication1
{
	partial class formularioPizarra
	{
		/// <summary>
		/// Variable del diseñador requerida.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Limpiar los recursos que se estén utilizando.
		/// </summary>
		/// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Código generado por el Diseñador de Windows Forms

		/// <summary>
		/// Método necesario para admitir el Diseñador. No se puede modificar
		/// el contenido del método con el editor de código.
		/// </summary>
		private void InitializeComponent()
		{
            this.btnCerrar = new System.Windows.Forms.Button();
            this.btnPunto = new System.Windows.Forms.Button();
            this.gb = new System.Windows.Forms.GroupBox();
            this.btnLínea = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.lColor = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.gb.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCerrar
            // 
            this.btnCerrar.Location = new System.Drawing.Point(261, 227);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(75, 23);
            this.btnCerrar.TabIndex = 0;
            this.btnCerrar.Text = "Cerrar";
            this.btnCerrar.UseVisualStyleBackColor = true;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // btnPunto
            // 
            this.btnPunto.Location = new System.Drawing.Point(15, 32);
            this.btnPunto.Name = "btnPunto";
            this.btnPunto.Size = new System.Drawing.Size(54, 22);
            this.btnPunto.TabIndex = 1;
            this.btnPunto.Text = "Punto";
            this.btnPunto.UseVisualStyleBackColor = true;
            this.btnPunto.Click += new System.EventHandler(this.btnPunto_Click);
            // 
            // gb
            // 
            this.gb.Controls.Add(this.btnLínea);
            this.gb.Controls.Add(this.label1);
            this.gb.Controls.Add(this.comboBox2);
            this.gb.Controls.Add(this.lColor);
            this.gb.Controls.Add(this.comboBox1);
            this.gb.Controls.Add(this.btnPunto);
            this.gb.Location = new System.Drawing.Point(12, 12);
            this.gb.Name = "gb";
            this.gb.Size = new System.Drawing.Size(168, 238);
            this.gb.TabIndex = 2;
            this.gb.TabStop = false;
            this.gb.Text = "Paleta";
            this.gb.Enter += new System.EventHandler(this.gb_Enter);
            // 
            // btnLínea
            // 
            this.btnLínea.Location = new System.Drawing.Point(93, 32);
            this.btnLínea.Name = "btnLínea";
            this.btnLínea.Size = new System.Drawing.Size(54, 22);
            this.btnLínea.TabIndex = 7;
            this.btnLínea.Text = "Línea";
            this.btnLínea.UseVisualStyleBackColor = true;
            this.btnLínea.Click += new System.EventHandler(this.btnLínea_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Grosor";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(62, 108);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(85, 21);
            this.comboBox2.TabIndex = 5;
            // 
            // lColor
            // 
            this.lColor.AutoSize = true;
            this.lColor.Location = new System.Drawing.Point(12, 78);
            this.lColor.Name = "lColor";
            this.lColor.Size = new System.Drawing.Size(31, 13);
            this.lColor.TabIndex = 4;
            this.lColor.Text = "Color";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(62, 78);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(85, 21);
            this.comboBox1.TabIndex = 3;
            // 
            // formularioPizarra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 262);
            this.Controls.Add(this.gb);
            this.Controls.Add(this.btnCerrar);
            this.Name = "formularioPizarra";
            this.Text = "Pizarra";
            this.Click += new System.EventHandler(this.Form1_Click);
            this.gb.ResumeLayout(false);
            this.gb.PerformLayout();
            this.ResumeLayout(false);

		}

		#endregion

        private System.Windows.Forms.Button btnCerrar;
        private System.Windows.Forms.Button btnPunto;
        private System.Windows.Forms.GroupBox gb;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label lColor;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLínea;
	}
}

