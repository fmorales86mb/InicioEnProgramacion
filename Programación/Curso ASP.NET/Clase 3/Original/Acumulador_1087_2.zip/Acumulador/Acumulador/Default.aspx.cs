﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Acumulador
{
    public partial class Default : System.Web.UI.Page
    {
        int i = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                this.lblMensaje.Text = "Sin un mecanismo auxilliar es imposible mantener el estado de la variable: el valor nunca se incrementa más allá de 1."; 
            }
        }

        protected void Button_Click(object sender, EventArgs e)
        {
            i++;
            this.lblValor.Text = "Valor de la variable: " + i.ToString();
        }
    }
}