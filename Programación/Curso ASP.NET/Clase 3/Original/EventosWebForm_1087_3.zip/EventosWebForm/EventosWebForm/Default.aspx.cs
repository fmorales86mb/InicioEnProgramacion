﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EventosWebForm
{
    public partial class Default : System.Web.UI.Page
    {

        protected void Page_Init(object sender, System.EventArgs e)
        {
            Response.Write("1. Page_Init </br>");
        }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Write("2. Page_Load </br>");
        }

        protected void Page_PreRender(object sender, System.EventArgs e)
        {
            Response.Write("3. Page_PreRender </br>");
        }

        private void Page_Unload(object sender, System.EventArgs e)
        {
           //Aquí ya no es posible generar una salida ya que la página fue "rendeada".
        }
    }
}